# Project {Name}

![Licencia](https://img.shields.io/badge/Licencia-MIT-green.svg)

## Description

TODO: A brief description of your project, what it does and why it is useful.

## Index

1. [Requirements](#requirements)
2. [Installation](#installation)
3. [Usage](#usage)
4. [Features](#features)
5. [Contributing](#contributing)
6. [Credits](#credits)
7. [License](#license)

## Requirements

- SO: Linux, Windows
- vscode: [vscode](https://code.visualstudio.com/)
- Visual Studio: [Visual Studio](https://visualstudio.microsoft.com/) (característica desarrollo C/C++ escritorio)
- Docker : [Docker](https://www.docker.com/), seguir las instrucciones de instalación para su sistema operativo.

## Installation

### Using DevContainer (recommended)

Use the DevContainer development environment in VS Code to simplify setup and avoid dependency issues.

You don't need anything special for this (just have the Remote - Containers extension installed). When you open the project folder in VS Code it will detect the `.devcontainer/devcontainer.json` file and ask if you want to open the folder in the container — accept.

If you don't receive the notification, you can open the container manually:

1. Open the Command Palette (Ctrl+Shift+P).
2. Type "Dev Containers: Reopen in Container" and select the option.

VS Code will build the container and open the project inside it. The environment will be ready to use with all dependencies installed.

### Install dependencies with Poetry

```sh
# create a new virtual environment and install dependencies
poetry install
```

Commands useful for Poetry:

```sh
# Add new dependencies when necessary:
poetry add <package-name>
poetry add <package-name>@0.24.0
# View versions of a package:
pip index versions <package-name>
```

```sh
# List virtual environments:
poetry env list
# Remove current virtual environment:
poetry env remove python

```

... (TODO: rest of the README content) ...
